﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Retangulo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Valores valores;
            valores = new Valores();

            Console.WriteLine("Calcular área do Retâgulo");

            Console.WriteLine("Informe a Base: ");
            valores.ba = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Informe a Altura: ");
            valores.alt = Convert.ToInt32(Console.ReadLine());

            int re = valores.ba * valores.alt;

            Console.WriteLine("O valor da área do retângulo é: " + re);

            Console.ReadKey();
        }
    }
}
